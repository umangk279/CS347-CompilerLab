#define EOI 0 /* End of input */
#define SEMI 1 /* ; */
#define PLUS 2 /* + */
#define TIMES 3 /* * */
#define LP 4 /* ( */
#define RP 5 /* ) */
#define NUM_OR_ID 6 /* Decimal Number or Identifier */

extern char *yytext; /* in lex.c */
extern int yyleng;
extern yylineno;

char* abc(   int x,float* y);
int main( int a )
{
 /* statement
 \



 _block */
	if(int a)
	 int a;
	int a[10];
 return 0;

}
