regex re_fun_def("(([a-zA-Z_][a-zA-Z_0-9]*[\\s\\*]*?){2,}\\(([^!@#$+%^;\\{\\}]*?)\\)[\\s]*\\{(.*)\\})");				//DOTALL
																								 ^
																								 | anything between braces